
const express=require('express');
const mongoose=require('mongoose');

const app=express();

mongoose.connect('mongodb+srv://hainvph36038:9C2Nyr3U7U77D2EV@cluster0.7xq7cf3.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0',{
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(()=>{
    console.log("Ket noi thanh cong voi mongodb")
}).catch((err)=>{
    console.error("Loi:",err);
});

//chon csdl thao tac
const db1=mongoose.connection.useDb('db1');
//dinh nghia model cho bang du lieu
const SinhVienSchema=new mongoose.Schema({
    masv:String,
    tensv:String
});
//anh xa model vao bang du lieu
const SinhVien=db1.model('sinhvien',SinhVienSchema);
// tao link trieu goi tren trinh duyet API
app.get('/',async (req,res)=>{
    try {
        const sinhvien= await SinhVien.find();
        if(sinhvien.length>0){
            res.json(sinhvien);
        }
        else
        {
            res.status(404).json({error:"khong co sinh vien"});
        }
    } catch (error) {
        console.error("Loi doc du lieu: ");
        res.status(500).json({error: "Doc du lieu loi"});
    }
});

const PORT=process.env.PORT|| 5000;
app.listen(PORT,()=>{
console.log('server dang chay o cong 5000');
});
module.exports=app;